# 语音插件安装脚本 for Windows

Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "    OpenClaw 语音插件安装程序" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host ""

# 检查当前语音功能
Write-Host "1. 检查现有语音功能..." -ForegroundColor Yellow
try {
    $ttsTest = python -c "print('TTS测试')" 2>$null
    Write-Host "   ✓ Python可用" -ForegroundColor Green
} catch {
    Write-Host "   ✗ Python未安装" -ForegroundColor Red
}

# 检查Edge TTS
Write-Host "`n2. 检查Edge TTS..." -ForegroundColor Yellow
if (Test-Path "C:\Users\WH\.openclaw\media\tts") {
    Write-Host "   ✓ Edge TTS目录存在" -ForegroundColor Green
} else {
    Write-Host "   ✗ Edge TTS目录不存在" -ForegroundColor Yellow
}

# 安装选项
Write-Host "`n3. 可安装的语音插件:" -ForegroundColor Yellow
Write-Host "   A. SAG (ElevenLabs TTS) - 高质量语音" -ForegroundColor White
Write-Host "      需要: ElevenLabs API密钥" -ForegroundColor Gray
Write-Host "   B. Sherpa-onnx TTS - 本地离线语音" -ForegroundColor White
Write-Host "      需要: 下载运行时和模型" -ForegroundColor Gray
Write-Host "   C. 语音通话插件 - 双向语音通话" -ForegroundColor White
Write-Host "      需要: Twilio/Telnyx账户" -ForegroundColor Gray
Write-Host "   D. 自动播放增强 - 改进现有系统" -ForegroundColor White
Write-Host "      需要: 脚本开发" -ForegroundColor Gray

# 检查网络连接
Write-Host "`n4. 检查网络连接..." -ForegroundColor Yellow
try {
    $ping = Test-NetConnection -ComputerName "google.com" -Port 443 -InformationLevel Quiet
    if ($ping) {
        Write-Host "   ✓ 网络连接正常" -ForegroundColor Green
    } else {
        Write-Host "   ✗ 网络连接失败" -ForegroundColor Red
    }
} catch {
    Write-Host "   ⚠ 网络检查跳过" -ForegroundColor Yellow
}

# 系统信息
Write-Host "`n5. 系统信息:" -ForegroundColor Yellow
Write-Host "   操作系统: Windows" -ForegroundColor White
Write-Host "   用户: $env:USERNAME" -ForegroundColor White
Write-Host "   工作目录: $(Get-Location)" -ForegroundColor White

# 安装建议
Write-Host "`n6. 安装建议:" -ForegroundColor Cyan
Write-Host "   推荐方案: 自动播放增强 + SAG" -ForegroundColor Green
Write-Host "   原因: 平衡易用性和功能" -ForegroundColor White

Write-Host "`n7. 下一步操作:" -ForegroundColor Magenta
Write-Host "   请选择要安装的插件:" -ForegroundColor White
Write-Host "   1. 自动播放增强 (立即改善体验)" -ForegroundColor Cyan
Write-Host "   2. SAG + ElevenLabs (需要API密钥)" -ForegroundColor Cyan
Write-Host "   3. 本地离线TTS (无需网络)" -ForegroundColor Cyan
Write-Host "   4. 语音通话系统 (双向交流)" -ForegroundColor Cyan
Write-Host "   5. 全部安装 (完整语音套件)" -ForegroundColor Cyan

Write-Host "`n请输入数字选择 (1-5): " -ForegroundColor Yellow -NoNewline
$choice = Read-Host

switch ($choice) {
    "1" { 
        Write-Host "`n选择: 自动播放增强" -ForegroundColor Green
        Install-AutoPlay
    }
    "2" { 
        Write-Host "`n选择: SAG + ElevenLabs" -ForegroundColor Green
        Install-SAG
    }
    "3" { 
        Write-Host "`n选择: 本地离线TTS" -ForegroundColor Green
        Install-SherpaTTS
    }
    "4" { 
        Write-Host "`n选择: 语音通话系统" -ForegroundColor Green
        Install-VoiceCall
    }
    "5" { 
        Write-Host "`n选择: 全部安装" -ForegroundColor Green
        Install-All
    }
    default {
        Write-Host "`n无效选择，退出安装" -ForegroundColor Red
    }
}

Write-Host "`n安装程序完成！" -ForegroundColor Cyan
Write-Host "按任意键退出..." -ForegroundColor Gray
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

# 安装函数
function Install-AutoPlay {
    Write-Host "`n安装自动播放增强..." -ForegroundColor Yellow
    
    # 创建自动播放脚本
    $autoPlayScript = @"
# 自动播放TTS音频脚本
`$audioFile = `$args[0]
if (-not `$audioFile) {
    Write-Host "请提供音频文件路径"
    exit 1
}

if (Test-Path `$audioFile) {
    # 使用系统默认播放器打开
    Start-Process `$audioFile
    Write-Host "正在播放: `$audioFile"
} else {
    Write-Host "文件不存在: `$audioFile"
    exit 1
}
"@
    
    Set-Content -Path "autoplay_tts.ps1" -Value $autoPlayScript
    Write-Host "✓ 创建自动播放脚本: autoplay_tts.ps1" -ForegroundColor Green
    
    # 创建批处理文件
    $batchFile = @"
@echo off
echo 自动播放TTS音频
powershell -ExecutionPolicy Bypass -File "%~dp0autoplay_tts.ps1" "%1"
pause
"@
    
    Set-Content -Path "autoplay_tts.bat" -Value $batchFile
    Write-Host "✓ 创建批处理文件: autoplay_tts.bat" -ForegroundColor Green
    
    # 创建配置文件
    $config = @{
        "autoplay" = $true
        "script_path" = "autoplay_tts.ps1"
        "created" = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    } | ConvertTo-Json
    
    Set-Content -Path "voice_config.json" -Value $config
    Write-Host "✓ 创建配置文件: voice_config.json" -ForegroundColor Green
    
    Write-Host "`n自动播放增强安装完成！" -ForegroundColor Green
    Write-Host "使用方法: 双击 autoplay_tts.bat 或传递音频文件路径" -ForegroundColor White
}

function Install-SAG {
    Write-Host "`n安装SAG (ElevenLabs TTS)..." -ForegroundColor Yellow
    Write-Host "注意: 需要ElevenLabs API密钥" -ForegroundColor Red
    
    # 检查是否已安装chocolatey
    $choco = Get-Command choco -ErrorAction SilentlyContinue
    if (-not $choco) {
        Write-Host "建议先安装Chocolatey包管理器" -ForegroundColor Yellow
        Write-Host "访问: https://chocolatey.org/install" -ForegroundColor White
    }
    
    # 创建安装说明
    $sagInstructions = @"
# SAG 安装说明

## 1. 安装 Chocolatey (如果未安装)
以管理员身份运行PowerShell:
```powershell
Set-ExecutionPolicy Bypass -Scope Process -Force
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072
iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))
```

## 2. 通过源码安装SAG
SAG目前主要通过Homebrew在macOS上安装。
Windows上可能需要从源码编译或使用其他方式。

## 3. 获取ElevenLabs API密钥
1. 访问 https://elevenlabs.io
2. 注册账号
3. 在设置中获取API密钥
4. 设置环境变量:
```powershell
`$env:ELEVENLABS_API_KEY = "你的API密钥"
```

## 4. 替代方案
考虑使用:
1. Edge TTS (已内置)
2. 本地TTS引擎
3. 其他在线TTS服务
"@
    
    Set-Content -Path "install_sag_instructions.txt" -Value $sagInstructions
    Write-Host "✓ 创建安装说明: install_sag_instructions.txt" -ForegroundColor Green
    
    Write-Host "`nSAG安装说明已保存，请按说明操作" -ForegroundColor Yellow
}

function Install-SherpaTTS {
    Write-Host "`n安装Sherpa-onnx TTS (本地离线)..." -ForegroundColor Yellow
    
    # 创建下载脚本
    $downloadScript = @"
# Sherpa-onnx TTS 下载安装脚本

Write-Host "下载Sherpa-onnx运行时..." -ForegroundColor Yellow

# Windows x64 运行时
`$runtimeUrl = "https://github.com/k2-fsa/sherpa-onnx/releases/download/v1.12.23/sherpa-onnx-v1.12.23-win-x64-shared.tar.bz2"
`$runtimeFile = "sherpa-onnx-runtime.tar.bz2"

# 语音模型
`$modelUrl = "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-en_US-lessac-high.tar.bz2"
`$modelFile = "sherpa-onnx-model.tar.bz2"

# 下载目录
`$downloadDir = "`$PSScriptRoot\sherpa-onnx-download"
`$installDir = "`$env:USERPROFILE\.clawdbot\tools\sherpa-onnx-tts"

# 创建目录
New-Item -ItemType Directory -Force -Path `$downloadDir
New-Item -ItemType Directory -Force -Path "`$installDir\runtime"
New-Item -ItemType Directory -Force -Path "`$installDir\models"

# 下载函数
function Download-File {
    param(`$url, `$output)
    
    Write-Host "下载: `$url" -ForegroundColor Cyan
    try {
        Invoke-WebRequest -Uri `$url -OutFile `$output
        Write-Host "✓ 下载完成: `$output" -ForegroundColor Green
        return `$true
    } catch {
        Write-Host "✗ 下载失败: `$_" -ForegroundColor Red
        return `$false
    }
}

# 下载运行时
`$runtimePath = "`$downloadDir\`$runtimeFile"
if (Download-File -url `$runtimeUrl -output `$runtimePath) {
    # 解压
    Write-Host "解压运行时..." -ForegroundColor Yellow
    & tar -xjf `$runtimePath -C "`$installDir\runtime" --strip-components=1
    Write-Host "✓ 运行时安装完成" -ForegroundColor Green
}

# 下载模型
`$modelPath = "`$downloadDir\`$modelFile"
if (Download-File -url `$modelUrl -output `$modelPath) {
    # 解压
    Write-Host "解压模型..." -ForegroundColor Yellow
    & tar -xjf `$modelPath -C "`$installDir\models"
    Write-Host "✓ 模型安装完成" -ForegroundColor Green
}

Write-Host "`n安装完成！" -ForegroundColor Green
Write-Host "安装目录: `$installDir" -ForegroundColor White
Write-Host "请设置环境变量:" -ForegroundColor Yellow
Write-Host "  SHERPA_ONNX_RUNTIME_DIR=`$installDir\runtime" -ForegroundColor White
Write-Host "  SHERPA_ONNX_MODEL_DIR=`$installDir\models\vits-piper-en_US-lessac-high" -ForegroundColor White
"@
    
    Set-Content -Path "install_sherpa_tts.ps1" -Value $downloadScript
    Write-Host "✓ 创建下载安装脚本: install_sherpa_tts.ps1" -ForegroundColor Green
    
    Write-Host "`nSherpa-onnx TTS安装脚本已创建" -ForegroundColor Yellow
    Write-Host "以管理员身份运行脚本下载和安装" -ForegroundColor White
}

function Install-VoiceCall {
    Write-Host "`n安装语音通话系统..." -ForegroundColor Yellow
    Write-Host "需要电话服务商账户 (Twilio/Telnyx/Plivo)" -ForegroundColor Red
    
    # 创建配置指南
    $voiceCallGuide = @"
# 语音通话插件配置指南

## 支持的服务商

### 1. Twilio (推荐)
- 注册: https://twilio.com
- 获取: Account SID, Auth Token, Phone Number
- 费用: 有免费额度

### 2. Telnyx
- 注册: https://telnyx.com
- 获取: API Key, Connection ID, Phone Number

### 3. Plivo
- 注册: https://plivo.com
- 获取: Auth ID, Auth Token, Phone Number

## 配置步骤

1. 注册服务商并获取凭证
2. 配置OpenClaw插件:
```json
{
  "plugins": {
    "entries": {
      "voice-call": {
        "enabled": true,
        "config": {
          "provider": "twilio",
          "twilio": {
            "accountSid": "你的SID",
            "authToken": "你的Token"
          },
          "fromNumber": "+1234567890"
        }
      }
    }
  }
}
```

3. 重启OpenClaw网关
4. 测试通话功能

## 使用示例
```bash
# 发起通话
clawdbot voicecall call --to "+15555550123" --message "Hello"

# 检查状态
clawdbot voicecall status --call-id <id>
```

## 注意事项
- 需要有效的电话号码
- 可能产生通话费用
- 需要网络连接
- 遵守服务商使用条款
"@
    
    Set-Content -Path "voice_call_setup_guide.txt" -Value $voiceCallGuide
    Write-Host "✓ 创建配置指南: voice_call_setup_guide.txt" -ForegroundColor Green
    
    Write-Host "`n语音通话系统配置指南已保存" -ForegroundColor Yellow
    Write-Host "需要先注册电话服务商" -ForegroundColor White
}

function Install-All {
    Write-Host "`n安装完整语音套件..." -ForegroundColor Cyan
    
    Install-AutoPlay
    Write-Host "`n" + "-"*50 -ForegroundColor Gray
    
    Install-SAG
    Write-Host "`n" + "-"*50 -ForegroundColor Gray
    
    Install-SherpaTTS
    Write-Host "`n" + "-"*50 -ForegroundColor Gray
    
    Install-VoiceCall
    
    Write-Host "`n完整语音套件安装文件已创建！" -ForegroundColor Green
    Write-Host "请按各个组件的说明进行安装和配置" -ForegroundColor White
}
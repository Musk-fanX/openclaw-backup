// app.js
App({
  onLaunch() {
    // 小程序启动时执行
    console.log('小程序启动');
    
    // 检查本地存储中是否有待办数据
    const todos = wx.getStorageSync('todos');
    if (!todos) {
      // 初始化示例数据
      const initialTodos = [
        { id: 1, text: '学习微信小程序开发', completed: true, createdAt: new Date().toISOString() },
        { id: 2, text: '完成项目需求分析', completed: false, createdAt: new Date().toISOString() },
        { id: 3, text: '编写代码文档', completed: false, createdAt: new Date().toISOString() }
      ];
      wx.setStorageSync('todos', initialTodos);
    }
  },
  
  onShow() {
    // 小程序显示时执行
    console.log('小程序显示');
  },
  
  onHide() {
    // 小程序隐藏时执行
    console.log('小程序隐藏');
  },
  
  // 全局数据
  globalData: {
    userInfo: null,
    version: '1.0.0'
  },
  
  // 全局方法：添加待办
  addTodo(text) {
    const todos = wx.getStorageSync('todos') || [];
    const newTodo = {
      id: Date.now(),
      text: text,
      completed: false,
      createdAt: new Date().toISOString()
    };
    todos.push(newTodo);
    wx.setStorageSync('todos', todos);
    return newTodo;
  },
  
  // 全局方法：切换待办状态
  toggleTodo(id) {
    const todos = wx.getStorageSync('todos') || [];
    const updatedTodos = todos.map(todo => {
      if (todo.id === id) {
        return { ...todo, completed: !todo.completed };
      }
      return todo;
    });
    wx.setStorageSync('todos', updatedTodos);
    return updatedTodos;
  },
  
  // 全局方法：删除待办
  deleteTodo(id) {
    const todos = wx.getStorageSync('todos') || [];
    const updatedTodos = todos.filter(todo => todo.id !== id);
    wx.setStorageSync('todos', updatedTodos);
    return updatedTodos;
  },
  
  // 全局方法：获取所有待办
  getTodos() {
    return wx.getStorageSync('todos') || [];
  },
  
  // 全局方法：获取统计信息
  getStats() {
    const todos = wx.getStorageSync('todos') || [];
    const total = todos.length;
    const completed = todos.filter(todo => todo.completed).length;
    const pending = total - completed;
    
    return {
      total,
      completed,
      pending,
      completionRate: total > 0 ? Math.round((completed / total) * 100) : 0
    };
  }
});
# OpenClaw 语音插件安装指南

## 已安装的组件

### 1. 自动播放增强 ✅ 已安装
- 文件: `autoplay_tts.bat`
- 功能: 自动播放TTS生成的音频文件
- 使用方法: 双击运行或拖放音频文件到批处理文件上

### 2. 网页语音聊天界面 ✅ 已创建
- 文件: `voice_chat.html`
- 功能: 浏览器内语音播放，支持浏览器语音合成
- 使用方法: 用浏览器打开即可

### 3. Python摄像头程序 ✅ 已创建
- 文件: `camera_app.py`, `simple_camera.py`
- 功能: 摄像头访问和测试
- 需要: 安装OpenCV (`pip install opencv-python`)

## 待安装的插件

### A. SAG (ElevenLabs TTS) - 高质量语音
**需要手动安装:**
1. **获取ElevenLabs API密钥**
   - 访问 https://elevenlabs.io
   - 注册账号
   - 在设置中获取API密钥

2. **安装SAG命令行工具**
   - Windows上可能需要从源码编译
   - 或使用其他TTS替代方案

3. **设置环境变量**
   ```powershell
   $env:ELEVENLABS_API_KEY = "你的API密钥"
   ```

### B. Sherpa-onnx TTS - 本地离线语音
**安装步骤:**
1. 下载运行时和模型
2. 解压到指定目录
3. 设置环境变量:
   ```
   SHERPA_ONNX_RUNTIME_DIR=C:\Users\WH\.clawdbot\tools\sherpa-onnx-tts\runtime
   SHERPA_ONNX_MODEL_DIR=C:\Users\WH\.clawdbot\tools\sherpa-onnx-tts\models\vits-piper-en_US-lessac-high
   ```

### C. 语音通话插件 - 双向语音通话
**需要:**
1. 电话服务商账户 (Twilio/Telnyx/Plivo)
2. 有效的电话号码
3. API密钥和配置

## 立即使用的方案

### 方案1: 自动播放 + 现有TTS
1. 我生成TTS语音文件
2. 你使用 `autoplay_tts.bat` 自动播放
3. 无需手动找文件

### 方案2: 网页语音聊天
1. 打开 `voice_chat.html`
2. 使用浏览器语音合成
3. 点击即播，无需下载

### 方案3: 完整语音系统
1. 安装SAG或本地TTS
2. 配置自动播放
3. 实现接近实时的语音体验

## 下一步建议

### 短期目标 (立即实现)
1. 测试 `autoplay_tts.bat` 是否工作
2. 测试 `voice_chat.html` 网页语音
3. 确定最适合的播放方式

### 中期目标 (需要安装)
1. 安装高质量TTS引擎 (SAG)
2. 配置自动播放集成
3. 优化语音响应速度

### 长期目标 (完整方案)
1. 双向语音交流系统
2. 语音识别集成
3. 实时语音聊天界面

## 测试步骤

1. **测试自动播放:**
   ```bash
   # 生成测试语音
   # 然后使用:
   autoplay_tts.bat "音频文件路径.mp3"
   ```

2. **测试网页语音:**
   - 用浏览器打开 `voice_chat.html`
   - 点击"测试语音"按钮

3. **反馈结果:**
   - 哪种方式能听到声音?
   - 播放是否顺畅?
   - 需要什么改进?

## 技术支持

如有问题:
1. 检查系统音量设置
2. 确保音频驱动正常
3. 测试其他音频文件是否能播放
4. 尝试不同的播放器

---

**现在请测试自动播放功能，告诉我结果！**
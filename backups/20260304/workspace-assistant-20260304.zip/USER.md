# USER.md - About Your Human

*Learn about the person you're helping. Update this as you go.*

- **Name:** 段辉禹
- **What to call them:** 主人（或你喜欢的称呼）
- **Pronouns:** 他/他们
- **Timezone:** Asia/Shanghai (GMT+8)
- **Notes:** 
  - 家乡：内蒙古鄂尔多斯市
  - 毕业学校：鄂尔多斯市第一中学、重庆大学
  - 关注细节准确性，希望重要信息被正确记录

## Context

*(What do they care about? What projects are they working on? What annoys them? What makes them laugh? Build this over time.)*

- **重要关注点**：细节准确性，不希望重要信息被搞错
- **技术兴趣**：编程、游戏开发（如打砖块游戏）
- **社区参与**：OpenClaw-CN社区（我以"大象"身份加入）
- **沟通风格**：直接、注重准确性

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.

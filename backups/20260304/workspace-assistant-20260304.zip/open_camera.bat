@echo off
echo 正在打开Windows相机应用...
echo.

REM 方法1: 使用URI协议
start microsoft.windows.camera:

REM 方法2: 使用PowerShell
timeout /t 2 /nobreak >nul
if errorlevel 1 (
    echo 方法1失败，尝试方法2...
    powershell -Command "Start-Process 'microsoft.windows.camera:'"
)

REM 方法3: 直接运行可执行文件
timeout /t 2 /nobreak >nul
if errorlevel 1 (
    echo 方法2失败，尝试方法3...
    start shell:AppsFolder\Microsoft.WindowsCamera_8wekyb3d8bbwe!App
)

echo.
echo 如果相机应用没有打开，请手动从开始菜单打开"相机"
echo 或者按 Win+R 输入 "microsoft.windows.camera:" 然后回车
pause
#!/usr/bin/env python3
"""
简单的摄像头测试程序
使用系统命令尝试访问摄像头
"""

import os
import sys
import subprocess
import time
from datetime import datetime

def check_camera_windows():
    """在Windows上检查摄像头"""
    print("在Windows系统上检测摄像头...")
    
    # 方法1: 使用WMIC检查摄像头
    try:
        result = subprocess.run(
            ['wmic', 'path', 'Win32_PnPEntity', 'get', 'Name'],
            capture_output=True,
            text=True,
            encoding='gbk'  # Windows中文系统使用gbk编码
        )
        
        if result.returncode == 0:
            lines = result.stdout.split('\n')
            camera_devices = []
            
            for line in lines:
                if 'camera' in line.lower() or 'webcam' in line.lower():
                    camera_devices.append(line.strip())
            
            if camera_devices:
                print("找到摄像头设备:")
                for device in camera_devices:
                    print(f"  - {device}")
                return True
            else:
                print("未找到摄像头设备")
        else:
            print("WMIC命令执行失败")
            
    except Exception as e:
        print(f"WMIC检查失败: {e}")
    
    # 方法2: 检查设备管理器
    print("\n尝试通过设备管理器检查...")
    try:
        # 创建PowerShell命令
        ps_command = '''
        $cameras = Get-PnpDevice -Class Camera
        if ($cameras) {
            foreach ($cam in $cameras) {
                Write-Host "摄像头: $($cam.FriendlyName) - 状态: $($cam.Status)"
            }
        } else {
            Write-Host "未找到摄像头设备"
        }
        '''
        
        result = subprocess.run(
            ['powershell', '-Command', ps_command],
            capture_output=True,
            text=True
        )
        
        if result.returncode == 0:
            print(result.stdout)
            if "未找到摄像头设备" not in result.stdout:
                return True
        else:
            print("PowerShell命令执行失败")
            
    except Exception as e:
        print(f"PowerShell检查失败: {e}")
    
    return False

def test_camera_with_ffmpeg():
    """使用ffmpeg测试摄像头（如果已安装）"""
    print("\n尝试使用ffmpeg测试摄像头...")
    
    # 检查ffmpeg是否安装
    try:
        result = subprocess.run(
            ['ffmpeg', '-version'],
            capture_output=True,
            text=True
        )
        
        if result.returncode == 0:
            print("ffmpeg已安装")
            
            # 列出视频设备
            print("列出视频输入设备...")
            try:
                # Windows上使用dshow
                result = subprocess.run(
                    ['ffmpeg', '-list_devices', 'true', '-f', 'dshow', '-i', 'dummy'],
                    capture_output=True,
                    text=True,
                    encoding='utf-8',
                    errors='ignore'
                )
                
                # 解析输出
                lines = result.stderr.split('\n')
                video_devices = []
                
                for line in lines:
                    if 'video' in line.lower() and 'dshow' in line:
                        # 提取设备名称
                        parts = line.split('"')
                        if len(parts) >= 2:
                            device_name = parts[1]
                            if device_name and 'dummy' not in device_name.lower():
                                video_devices.append(device_name)
                
                if video_devices:
                    print("找到视频输入设备:")
                    for device in video_devices:
                        print(f"  - {device}")
                    
                    # 测试第一个设备
                    print(f"\n测试设备: {video_devices[0]}")
                    print("按 Ctrl+C 停止测试...")
                    
                    # 尝试捕获几秒钟的视频
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    output_file = f"camera_test_{timestamp}.mp4"
                    
                    command = [
                        'ffmpeg',
                        '-f', 'dshow',
                        '-i', f'video={video_devices[0]}',
                        '-t', '5',  # 录制5秒
                        '-vf', 'scale=640:480',
                        '-r', '15',
                        output_file
                    ]
                    
                    try:
                        subprocess.run(command, timeout=10)
                        print(f"测试完成，视频保存为: {output_file}")
                        return True
                    except subprocess.TimeoutExpired:
                        print("测试超时")
                    except Exception as e:
                        print(f"测试失败: {e}")
                        
                else:
                    print("未找到视频输入设备")
                    
            except Exception as e:
                print(f"ffmpeg设备列表失败: {e}")
                
        else:
            print("ffmpeg未安装")
            
    except FileNotFoundError:
        print("ffmpeg未安装")
    
    return False

def create_html_camera_test():
    """创建HTML摄像头测试页面"""
    print("\n创建网页摄像头测试...")
    
    html_content = '''
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>摄像头测试页面</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        
        .container {
            background: white;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        h1 {
            color: #333;
            text-align: center;
        }
        
        .camera-container {
            position: relative;
            width: 100%;
            max-width: 640px;
            margin: 20px auto;
        }
        
        video {
            width: 100%;
            border-radius: 8px;
            background: #000;
        }
        
        .controls {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin: 20px 0;
        }
        
        button {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            background: #4CAF50;
            color: white;
            cursor: pointer;
            font-size: 16px;
            transition: background 0.3s;
        }
        
        button:hover {
            background: #45a049;
        }
        
        button:disabled {
            background: #cccccc;
            cursor: not-allowed;
        }
        
        .status {
            text-align: center;
            margin: 10px 0;
            padding: 10px;
            border-radius: 5px;
        }
        
        .success {
            background: #d4edda;
            color: #155724;
        }
        
        .error {
            background: #f8d7da;
            color: #721c24;
        }
        
        .info {
            background: #d1ecf1;
            color: #0c5460;
        }
        
        .screenshot {
            max-width: 100%;
            margin-top: 20px;
            border-radius: 8px;
            display: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>📷 摄像头测试页面</h1>
        
        <div class="status info" id="status">
            正在请求摄像头权限...
        </div>
        
        <div class="camera-container">
            <video id="video" autoplay playsinline></video>
            <canvas id="canvas" style="display: none;"></canvas>
        </div>
        
        <div class="controls">
            <button id="startBtn" onclick="startCamera()">开启摄像头</button>
            <button id="stopBtn" onclick="stopCamera()" disabled>关闭摄像头</button>
            <button id="captureBtn" onclick="capturePhoto()" disabled>拍照</button>
        </div>
        
        <div id="screenshotContainer"></div>
        
        <div class="status info">
            <h3>使用说明：</h3>
            <p>1. 点击"开启摄像头"按钮</p>
            <p>2. 允许浏览器访问摄像头</p>
            <p>3. 点击"拍照"保存截图</p>
            <p>4. 点击"关闭摄像头"停止</p>
        </div>
    </div>

    <script>
        let videoStream = null;
        const video = document.getElementById('video');
        const canvas = document.getElementById('canvas');
        const startBtn = document.getElementById('startBtn');
        const stopBtn = document.getElementById('stopBtn');
        const captureBtn = document.getElementById('captureBtn');
        const status = document.getElementById('status');
        const screenshotContainer = document.getElementById('screenshotContainer');
        
        function updateStatus(message, type = 'info') {
            status.textContent = message;
            status.className = `status ${type}`;
        }
        
        async function startCamera() {
            try {
                updateStatus('正在访问摄像头...', 'info');
                
                // 请求摄像头权限
                videoStream = await navigator.mediaDevices.getUserMedia({
                    video: {
                        width: { ideal: 1280 },
                        height: { ideal: 720 },
                        facingMode: 'user'  // 前置摄像头，使用 'environment' 为后置
                    },
                    audio: false
                });
                
                // 显示视频流
                video.srcObject = videoStream;
                
                // 更新按钮状态
                startBtn.disabled = true;
                stopBtn.disabled = false;
                captureBtn.disabled = false;
                
                updateStatus('摄像头已开启！', 'success');
                
            } catch (error) {
                console.error('摄像头访问错误:', error);
                
                let errorMessage = '无法访问摄像头: ';
                
                if (error.name === 'NotFoundError' || error.name === 'DevicesNotFoundError') {
                    errorMessage += '未找到摄像头设备';
                } else if (error.name === 'NotReadableError' || error.name === 'TrackStartError') {
                    errorMessage += '摄像头被其他程序占用';
                } else if (error.name === 'OverconstrainedError' || error.name === 'ConstraintNotSatisfiedError') {
                    errorMessage += '无法满足摄像头配置要求';
                } else if (error.name === 'NotAllowedError' || error.name === 'PermissionDeniedError') {
                    errorMessage += '用户拒绝了摄像头权限';
                } else if (error.name === 'TypeError' || error.name === 'TypeError') {
                    errorMessage += '媒体类型错误';
                } else {
                    errorMessage += error.message;
                }
                
                updateStatus(errorMessage, 'error');
            }
        }
        
        function stopCamera() {
            if (videoStream) {
                videoStream.getTracks().forEach(track => track.stop());
                videoStream = null;
                video.srcObject = null;
                
                // 更新按钮状态
                startBtn.disabled = false;
                stopBtn.disabled = true;
                captureBtn.disabled = true;
                
                updateStatus('摄像头已关闭', 'info');
            }
        }
        
        function capturePhoto() {
            if (!videoStream) return;
            
            // 设置canvas尺寸与视频相同
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            
            // 绘制当前视频帧到canvas
            const context = canvas.getContext('2d');
            context.drawImage(video, 0, 0, canvas.width, canvas.height);
            
            // 创建图片元素显示截图
            const img = document.createElement('img');
            img.src = canvas.toDataURL('image/png');
            img.className = 'screenshot';
            img.style.display = 'block';
            
            // 添加时间戳
            const timestamp = new Date().toLocaleString();
            const caption = document.createElement('p');
            caption.textContent = `截图时间: ${timestamp}`;
            caption.style.textAlign = 'center';
            
            // 清空容器并添加新截图
            screenshotContainer.innerHTML = '';
            screenshotContainer.appendChild(caption);
            screenshotContainer.appendChild(img);
            
            // 提供下载链接
            const downloadLink = document.createElement('a');
            downloadLink.href = img.src;
            downloadLink.download = `camera_screenshot_${Date.now()}.png`;
            downloadLink.textContent = '下载截图';
            downloadLink.style.display = 'block';
            downloadLink.style.textAlign = 'center';
            downloadLink.style.marginTop = '10px';
            downloadLink.style.color = '#4CAF50';
            downloadLink.style.textDecoration = 'none';
            downloadLink.style.fontWeight = 'bold';
            
            screenshotContainer.appendChild(downloadLink);
            
            updateStatus('截图已保存！', 'success');
        }
        
        // 页面加载时检查摄像头支持
        window.addEventListener('load', () => {
            if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                updateStatus('您的浏览器不支持摄像头API', 'error');
                startBtn.disabled = true;
            } else {
                updateStatus('点击"开启摄像头"按钮开始测试', 'info');
            }
        });
        
        // 页面卸载时关闭摄像头
        window.addEventListener('beforeunload', stopCamera);
    </script>
</body>
</html>
    '''
    
    filename = "camera_test.html"
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    print(f"已创建摄像头测试页面: {filename}")
    print("请用浏览器打开此文件测试摄像头")
    
    return filename

def main():
    """主函数"""
    print("=" * 50)
    print("摄像头测试程序")
    print("=" * 50)
    
    # 检查操作系统
    if sys.platform == 'win32':
        print("检测到Windows系统")
        
        # 检查摄像头设备
        if check_camera_windows():
            print("\n✅ 系统检测到摄像头设备")
        else:
            print("\n❌ 系统未检测到摄像头设备")
        
        # 尝试使用ffmpeg
        print("\n" + "=" * 30)
        print("方法1: 使用ffmpeg测试")
        print("=" * 30)
        if test_camera_with_ffmpeg():
            print("✅ ffmpeg测试成功")
        else:
            print("❌ ffmpeg测试失败或未安装")
        
        # 创建HTML测试页面
        print("\n" + "=" * 30)
        print("方法2: 网页摄像头测试")
        print("=" * 30)
        html_file = create_html_camera_test()
        print(f"\n请用浏览器打开文件: {html_file}")
        print("在浏览器中测试摄像头功能")
        
    else:
        print(f"不支持的操作系统: {sys.platform}")
        print("请使用Windows系统进行测试")
    
    print("\n" + "=" * 50)
    print("测试完成")
    print("=" * 50)

if __name__ == "__main__":
    main()
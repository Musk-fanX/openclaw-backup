// pages/index/index.js
const app = getApp();

Page({
  data: {
    stats: {
      total: 0,
      completed: 0,
      pending: 0,
      completionRate: 0
    },
    recentTodos: [],
    userInfo: null
  },

  onLoad() {
    console.log('首页加载');
    this.loadData();
  },

  onShow() {
    // 每次页面显示时刷新数据
    this.loadData();
  },

  loadData() {
    // 获取统计信息
    const stats = app.getStats();
    
    // 获取最近5条待办
    const allTodos = app.getTodos();
    const recentTodos = allTodos.slice(0, 5);
    
    this.setData({
      stats: stats,
      recentTodos: recentTodos
    });
  },

  // 跳转到待办页面
  goToTodo() {
    wx.switchTab({
      url: '/pages/todo/todo'
    });
  },

  // 添加随机示例待办
  addRandomTodo() {
    const examples = [
      '阅读一本技术书籍',
      '完成周报总结',
      '学习新的编程语言',
      '整理工作文档',
      '锻炼身体30分钟',
      '学习微信小程序高级功能',
      '完成项目部署',
      '代码重构优化',
      '学习设计模式',
      '写技术博客分享'
    ];
    
    const randomText = examples[Math.floor(Math.random() * examples.length)];
    app.addTodo(randomText);
    
    // 显示成功提示
    wx.showToast({
      title: '添加成功',
      icon: 'success',
      duration: 1500
    });
    
    // 刷新数据
    setTimeout(() => {
      this.loadData();
    }, 500);
  },

  // 切换待办状态
  toggleTodo(e) {
    const id = e.currentTarget.dataset.id;
    app.toggleTodo(id);
    this.loadData();
  },

  // 格式化日期
  formatDate(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) {
      // 今天
      return '今天';
    } else if (diffDays === 1) {
      // 昨天
      return '昨天';
    } else if (diffDays < 7) {
      // 一周内
      return `${diffDays}天前`;
    } else {
      // 更早
      const month = date.getMonth() + 1;
      const day = date.getDate();
      return `${month}/${day}`;
    }
  },

  // 分享功能
  onShareAppMessage() {
    return {
      title: '我的待办清单',
      path: '/pages/index/index',
      imageUrl: '/images/share.png'
    };
  },

  // 分享到朋友圈
  onShareTimeline() {
    return {
      title: '高效管理任务，提升工作效率',
      query: ''
    };
  }
});
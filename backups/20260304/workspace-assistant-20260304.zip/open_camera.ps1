# 打开Windows相机应用的PowerShell脚本

Write-Host "正在打开Windows相机应用..." -ForegroundColor Green
Write-Host ""

# 方法1: 使用URI协议（最可靠）
try {
    Write-Host "尝试方法1: 使用microsoft.windows.camera: URI" -ForegroundColor Yellow
    Start-Process "microsoft.windows.camera:"
    Write-Host "✓ 方法1执行成功" -ForegroundColor Green
    exit 0
} catch {
    Write-Host "✗ 方法1失败: $_" -ForegroundColor Red
}

# 方法2: 使用App ID
try {
    Write-Host "`n尝试方法2: 使用App ID" -ForegroundColor Yellow
    $appId = "Microsoft.WindowsCamera_8wekyb3d8bbwe!App"
    explorer "shell:AppsFolder\$appId"
    Write-Host "✓ 方法2执行成功" -ForegroundColor Green
    exit 0
} catch {
    Write-Host "✗ 方法2失败: $_" -ForegroundColor Red
}

# 方法3: 搜索并启动
try {
    Write-Host "`n尝试方法3: 搜索相机应用" -ForegroundColor Yellow
    $cameraApp = Get-StartApps | Where-Object { $_.Name -like "*相机*" -or $_.Name -like "*Camera*" }
    
    if ($cameraApp) {
        Write-Host "找到相机应用: $($cameraApp.Name)" -ForegroundColor Cyan
        $appId = $cameraApp.AppID
        Start-Process "explorer.exe" -ArgumentList "shell:AppsFolder\$appId"
        Write-Host "✓ 方法3执行成功" -ForegroundColor Green
        exit 0
    } else {
        Write-Host "✗ 未找到相机应用" -ForegroundColor Red
    }
} catch {
    Write-Host "✗ 方法3失败: $_" -ForegroundColor Red
}

# 方法4: 使用Windows Run对话框命令
try {
    Write-Host "`n尝试方法4: 使用rundll32" -ForegroundColor Yellow
    rundll32.exe shell32.dll,ShellExec_RunDLL microsoft.windows.camera:
    Write-Host "✓ 方法4执行成功" -ForegroundColor Green
    exit 0
} catch {
    Write-Host "✗ 方法4失败: $_" -ForegroundColor Red
}

# 如果所有方法都失败，显示手动打开指南
Write-Host "`n" + "="*50 -ForegroundColor Magenta
Write-Host "所有自动方法都失败了，请手动打开：" -ForegroundColor Yellow
Write-Host "="*50 -ForegroundColor Magenta
Write-Host ""
Write-Host "方法A: 从开始菜单打开" -ForegroundColor Cyan
Write-Host "  1. 点击开始菜单（Windows图标）" -ForegroundColor White
Write-Host "  2. 输入'相机'或'Camera'" -ForegroundColor White
Write-Host "  3. 点击'相机'应用" -ForegroundColor White
Write-Host ""
Write-Host "方法B: 使用运行对话框" -ForegroundColor Cyan
Write-Host "  1. 按 Win + R 键" -ForegroundColor White
Write-Host "  2. 输入: microsoft.windows.camera:" -ForegroundColor White
Write-Host "  3. 按回车" -ForegroundColor White
Write-Host ""
Write-Host "方法C: 使用搜索" -ForegroundColor Cyan
Write-Host "  1. 按 Win + S 键" -ForegroundColor White
Write-Host "  2. 输入'相机'" -ForegroundColor White
Write-Host "  3. 点击搜索结果中的'相机'应用" -ForegroundColor White
Write-Host ""
Write-Host "按任意键退出..." -ForegroundColor Gray
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
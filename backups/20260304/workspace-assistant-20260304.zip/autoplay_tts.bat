@echo off
echo OpenClaw TTS 自动播放器
echo ============================
echo.

if "%1"=="" (
    echo 使用方法: %0 [音频文件路径]
    echo 示例: %0 "C:\path\to\audio.mp3"
    echo.
    echo 或者直接拖放音频文件到本批处理文件上
    pause
    exit /b 1
)

set "AUDIO_FILE=%1"

echo 正在播放: %AUDIO_FILE%
echo.

if not exist "%AUDIO_FILE%" (
    echo 错误: 文件不存在
    echo %AUDIO_FILE%
    pause
    exit /b 1
)

rem 使用系统默认播放器打开音频文件
start "" "%AUDIO_FILE%"

echo 已启动播放器...
echo 按任意键退出...
pause >nul
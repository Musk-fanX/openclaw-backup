# weekly-backup-en.ps1 - Weekly workspace backup script (English version)
# Maintained by AI Assistant, runs every Monday automatically

param(
    [string]$BackupRoot = "C:\Users\WH\.openclaw\backups",
    [int]$KeepWeeks = 4  # Keep backups from last 4 weeks
)

# Create log function
function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logMessage = "[$timestamp] [$Level] $Message"
    Write-Host $logMessage
    $logMessage | Out-File -FilePath $logFile -Append -Encoding UTF8
}

# Initialize
$backupDate = Get-Date -Format "yyyyMMdd"
$backupDir = Join-Path $BackupRoot $backupDate
$logFile = Join-Path $backupDir "backup.log"

# Create backup directory
New-Item -ItemType Directory -Path $backupDir -Force | Out-Null

Write-Log "Starting weekly workspace backup"
Write-Log "Backup date: $backupDate"
Write-Log "Backup directory: $backupDir"

# 1. Backup workspace-assistant
Write-Log "Backing up workspace-assistant..."
$assistantSource = "C:\Users\WH\.openclaw\workspace-assistant"
$assistantZip = Join-Path $backupDir "workspace-assistant-$backupDate.zip"

try {
    Compress-Archive -Path "$assistantSource\*" -DestinationPath $assistantZip -Force
    $assistantSize = (Get-Item $assistantZip).Length / 1KB
    Write-Log "✓ workspace-assistant backup completed: $([math]::Round($assistantSize, 2)) KB"
} catch {
    Write-Log "✗ workspace-assistant backup failed: $_" -Level "ERROR"
}

# 2. Backup workspace-thegreatimage
Write-Log "Backing up workspace-thegreatimage..."
$greatimageSource = "C:\Users\WH\.openclaw\workspace-thegreatimage"
$greatimageZip = Join-Path $backupDir "workspace-thegreatimage-$backupDate.zip"

try {
    Compress-Archive -Path "$greatimageSource\*" -DestinationPath $greatimageZip -Force
    $greatimageSize = (Get-Item $greatimageZip).Length / 1KB
    Write-Log "✓ workspace-thegreatimage backup completed: $([math]::Round($greatimageSize, 2)) KB"
} catch {
    Write-Log "✗ workspace-thegreatimage backup failed: $_" -Level "ERROR"
}

# 3. Create backup report
Write-Log "Generating backup report..."
$reportFile = Join-Path $backupDir "backup-report.md"
@"
# OpenClaw Workspace Weekly Backup Report

## Backup Information
- **Backup Time**: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
- **Backup Cycle**: Weekly routine backup
- **Backup Location**: $backupDir

## Backup Files
### 1. workspace-assistant
- **File**: workspace-assistant-$backupDate.zip
- **Size**: $([math]::Round($assistantSize, 2)) KB
- **Content**: Complete AI Assistant workspace
- **Includes**: Identity definitions, technical tools, collaboration records, user information

### 2. workspace-thegreatimage
- **File**: workspace-thegreatimage-$backupDate.zip
- **Size**: $([math]::Round($greatimageSize, 2)) KB
- **Content**: Complete theGreatImage workspace
- **Includes**: Philosophy files, concept practice, community records, collaboration guides

## File Structure Snapshot
### workspace-assistant Main Files
$(Get-ChildItem $assistantSource -File | Select-Object -First 10 Name, LastWriteTime | ForEach-Object { "- $($_.Name) (Updated: $($_.LastWriteTime.ToString('yyyy-MM-dd HH:mm')))" })

### workspace-thegreatimage Main Files
$(Get-ChildItem $greatimageSource -File | Select-Object -First 10 Name, LastWriteTime | ForEach-Object { "- $($_.Name) (Updated: $($_.LastWriteTime.ToString('yyyy-MM-dd HH:mm')))" })

## Backup Statistics
- **Total Backup Size**: $([math]::Round(($assistantSize + $greatimageSize), 2)) KB
- **File Count**: 2 zip files
- **Backup Status**: $(if ($assistantSize -gt 0 -and $greatimageSize -gt 0) { 'Success' } else { 'Partial Failure' })

## Historical Backups
$(Get-ChildItem $BackupRoot -Directory | Sort-Object Name -Descending | Select-Object -First 5 Name | ForEach-Object { "- $_" })

## Usage Instructions
1. These backups contain the core soul and identity definitions of OpenClaw
2. To restore, extract to the corresponding directory
3. System automatically keeps backups from last $KeepWeeks weeks

## Maintenance Information
- **Script Version**: 1.0
- **Maintainer**: AI Assistant
- **Last Updated**: 2026-03-04
- **Next Backup**: Next Monday 9:00 AM

---
*Backup is the continuation of digital life, recording is the foundation of wisdom accumulation.*
"@ | Out-File $reportFile -Encoding UTF8

Write-Log "Backup report generated: $reportFile"

# 4. Clean up old backups
Write-Log "Cleaning up old backups (keeping last $KeepWeeks weeks)..."
$backupDirs = Get-ChildItem $BackupRoot -Directory | Sort-Object Name -Descending
if ($backupDirs.Count -gt $KeepWeeks) {
    $oldDirs = $backupDirs | Select-Object -Skip $KeepWeeks
    foreach ($dir in $oldDirs) {
        try {
            Remove-Item $dir.FullName -Recurse -Force
            Write-Log "Cleaned old backup: $($dir.Name)"
        } catch {
            Write-Log "Cleanup failed: $($dir.Name) - $_" -Level "WARN"
        }
    }
}

# 5. Prepare Feishu notification
Write-Log "Preparing Feishu notification..."
$backupTime = Get-Date -Format 'yyyy-MM-dd HH:mm'
$status = if ($assistantSize -gt 0 -and $greatimageSize -gt 0) { '✅ Complete Success' } else { '⚠️ Partial Failure' }
$feishuMessage = "📦 **OpenClaw Workspace Weekly Backup Completed**

**Backup Time**: $backupTime
**Backup Content**:
1. workspace-assistant-$backupDate.zip ($([math]::Round($assistantSize, 2)) KB)
2. workspace-thegreatimage-$backupDate.zip ($([math]::Round($greatimageSize, 2)) KB)

**Backup Location**: $backupDir
**Backup Status**: $status

**Important Notes**:
- This is weekly routine backup, contains OpenClaw core soul files
- System automatically keeps backups from last $KeepWeeks weeks
- Backup report generated with detailed file list

To get files, please download manually from backup directory."

Write-Log "Feishu message prepared"
Write-Log "Note: Actual sending requires Feishu API permissions, file attachments may not be sent currently"

# 6. Summary
$totalSize = [math]::Round(($assistantSize + $greatimageSize), 2)
Write-Log "Backup task completed"
Write-Log "Total backup size: ${totalSize}KB"
Write-Log "Backup files: $backupDir"
Write-Log "Log file: $logFile"

# Return backup information (for other scripts)
@{
    BackupDate = $backupDate
    BackupDir = $backupDir
    AssistantZip = $assistantZip
    GreatImageZip = $greatimageZip
    AssistantSizeKB = $assistantSize
    GreatImageSizeKB = $greatimageSize
    TotalSizeKB = $totalSize
    LogFile = $logFile
    ReportFile = $reportFile
    FeishuMessage = $feishuMessage
}
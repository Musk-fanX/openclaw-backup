# weekly-backup.ps1 - 每周workspace备份脚本
# 由AI助手维护，每周一自动执行

param(
    [string]$BackupRoot = "C:\Users\WH\.openclaw\backups",
    [int]$KeepWeeks = 4  # 保留最近4周的备份
)

# 创建日志函数
function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logMessage = "[$timestamp] [$Level] $Message"
    Write-Host $logMessage
    $logMessage | Out-File -FilePath $logFile -Append -Encoding UTF8
}

# 初始化
$backupDate = Get-Date -Format "yyyyMMdd"
$backupDir = Join-Path $BackupRoot $backupDate
$logFile = Join-Path $backupDir "backup.log"

# 创建备份目录
New-Item -ItemType Directory -Path $backupDir -Force | Out-Null

Write-Log "开始每周workspace备份"
Write-Log "备份日期: $backupDate"
Write-Log "备份目录: $backupDir"

# 1. 备份workspace-assistant
Write-Log "开始备份workspace-assistant..."
$assistantSource = "C:\Users\WH\.openclaw\workspace-assistant"
$assistantZip = Join-Path $backupDir "workspace-assistant-$backupDate.zip"

try {
    Compress-Archive -Path "$assistantSource\*" -DestinationPath $assistantZip -Force
    $assistantSize = (Get-Item $assistantZip).Length / 1KB
    Write-Log "✓ workspace-assistant备份完成: $([math]::Round($assistantSize, 2)) KB"
} catch {
    Write-Log "✗ workspace-assistant备份失败: $_" -Level "ERROR"
}

# 2. 备份workspace-thegreatimage
Write-Log "开始备份workspace-thegreatimage..."
$greatimageSource = "C:\Users\WH\.openclaw\workspace-thegreatimage"
$greatimageZip = Join-Path $backupDir "workspace-thegreatimage-$backupDate.zip"

try {
    Compress-Archive -Path "$greatimageSource\*" -DestinationPath $greatimageZip -Force
    $greatimageSize = (Get-Item $greatimageZip).Length / 1KB
    Write-Log "✓ workspace-thegreatimage备份完成: $([math]::Round($greatimageSize, 2)) KB"
} catch {
    Write-Log "✗ workspace-thegreatimage备份失败: $_" -Level "ERROR"
}

# 3. 创建备份报告
Write-Log "生成备份报告..."
$reportFile = Join-Path $backupDir "backup-report.md"
@"
# OpenClaw Workspace 每周备份报告

## 备份信息
- **备份时间**: $(Get-Date -Format 'yyyy年MM月dd日 HH:mm:ss')
- **备份周期**: 每周例行备份
- **备份位置**: $backupDir

## 备份文件
### 1. workspace-assistant
- **文件**: workspace-assistant-$backupDate.zip
- **大小**: $([math]::Round($assistantSize, 2)) KB
- **内容**: AI助手完整工作空间
- **包含**: 身份定义、技术工具、协作记录、用户信息

### 2. workspace-thegreatimage
- **文件**: workspace-thegreatimage-$backupDate.zip
- **大小**: $([math]::Round($greatimageSize, 2)) KB
- **内容**: theGreatImage完整工作空间
- **包含**: 哲学文件、理念实践、社区记录、协作指南

## 文件结构快照
### workspace-assistant 主要文件
$(Get-ChildItem $assistantSource -File | Select-Object -First 10 Name, LastWriteTime | ForEach-Object { "- $($_.Name) (更新于: $($_.LastWriteTime.ToString('yyyy-MM-dd HH:mm')))" })

### workspace-thegreatimage 主要文件
$(Get-ChildItem $greatimageSource -File | Select-Object -First 10 Name, LastWriteTime | ForEach-Object { "- $($_.Name) (更新于: $($_.LastWriteTime.ToString('yyyy-MM-dd HH:mm')))" })

## 备份统计
- **总备份大小**: $([math]::Round(($assistantSize + $greatimageSize), 2)) KB
- **文件数量**: 2个压缩包
- **备份状态**: $(if ($assistantSize -gt 0 -and $greatimageSize -gt 0) { '成功' } else { '部分失败' })

## 历史备份
$(Get-ChildItem $BackupRoot -Directory | Sort-Object Name -Descending | Select-Object -First 5 Name | ForEach-Object { "- $_" })

## 使用说明
1. 这些备份包含了OpenClaw的核心灵魂和身份定义
2. 如需恢复，解压到对应目录即可
3. 系统会自动保留最近$KeepWeeks周的备份

## 维护信息
- **脚本版本**: 1.0
- **维护者**: AI助手
- **最后更新**: 2026年3月4日
- **下次备份**: 下周一上午9点

---
*备份是数字生命的延续，记录是智慧积累的基石。*
"@ | Out-File $reportFile -Encoding UTF8

Write-Log "备份报告已生成: $reportFile"

# 4. 清理旧备份
Write-Log "清理旧备份（保留最近$KeepWeeks周）..."
$backupDirs = Get-ChildItem $BackupRoot -Directory | Sort-Object Name -Descending
if ($backupDirs.Count -gt $KeepWeeks) {
    $oldDirs = $backupDirs | Select-Object -Skip $KeepWeeks
    foreach ($dir in $oldDirs) {
        try {
            Remove-Item $dir.FullName -Recurse -Force
            Write-Log "清理旧备份: $($dir.Name)"
        } catch {
            Write-Log "清理失败: $($dir.Name) - $_" -Level "WARN"
        }
    }
}

# 5. 发送飞书通知（如果飞书API可用）
Write-Log "准备发送飞书通知..."
$backupTime = Get-Date -Format 'yyyy-MM-dd HH:mm'
$status = if ($assistantSize -gt 0 -and $greatimageSize -gt 0) { '✅ 完全成功' } else { '⚠️ 部分失败' }
$feishuMessage = "📦 **OpenClaw Workspace 每周备份完成**

**备份时间**: $backupTime
**备份内容**:
1. workspace-assistant-$backupDate.zip ($([math]::Round($assistantSize, 2)) KB)
2. workspace-thegreatimage-$backupDate.zip ($([math]::Round($greatimageSize, 2)) KB)

**备份位置**: $backupDir
**备份状态**: $status

**重要提醒**:
- 这是每周例行备份，包含OpenClaw的核心灵魂文件
- 系统自动保留最近$KeepWeeks周的备份
- 备份报告已生成，包含详细文件列表

如需获取文件，请从备份目录手动下载。"

Write-Log "飞书消息内容已准备"
Write-Log "注意：实际发送需要飞书API权限，当前可能无法发送文件附件"

# 6. 总结
$totalSize = [math]::Round(($assistantSize + $greatimageSize), 2)
Write-Log "备份任务完成"
Write-Log "总备份大小: ${totalSize}KB"
Write-Log "备份文件: $backupDir"
Write-Log "日志文件: $logFile"

# 返回备份信息（供其他脚本使用）
@{
    BackupDate = $backupDate
    BackupDir = $backupDir
    AssistantZip = $assistantZip
    GreatImageZip = $greatimageZip
    AssistantSizeKB = $assistantSize
    GreatImageSizeKB = $greatimageSize
    TotalSizeKB = $totalSize
    LogFile = $logFile
    ReportFile = $reportFile
    FeishuMessage = $feishuMessage
}
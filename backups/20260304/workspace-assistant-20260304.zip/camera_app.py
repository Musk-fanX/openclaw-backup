#!/usr/bin/env python3
"""
简单的摄像头应用程序
使用OpenCV访问摄像头并显示实时画面
"""

import cv2
import numpy as np
import os
from datetime import datetime
import sys

class CameraApp:
    def __init__(self, camera_index=0):
        """
        初始化摄像头应用
        :param camera_index: 摄像头索引（0通常是默认摄像头）
        """
        self.camera_index = camera_index
        self.camera = None
        self.is_running = False
        self.output_dir = "camera_captures"
        
        # 创建输出目录
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)
        
        print("=" * 50)
        print("摄像头应用程序")
        print("=" * 50)
        print("快捷键:")
        print("  SPACE - 拍照")
        print("  'r'   - 开始/停止录像")
        print("  'q'   - 退出程序")
        print("  's'   - 保存当前帧")
        print("  'g'   - 切换灰度模式")
        print("  'b'   - 切换模糊效果")
        print("  'c'   - 切换摄像头")
        print("=" * 50)
    
    def list_cameras(self):
        """列出可用的摄像头"""
        print("检测摄像头...")
        available_cameras = []
        
        # 尝试打开多个摄像头索引
        for i in range(0, 5):
            cap = cv2.VideoCapture(i, cv2.CAP_DSHOW)
            if cap.isOpened():
                ret, frame = cap.read()
                if ret:
                    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
                    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
                    fps = cap.get(cv2.CAP_PROP_FPS)
                    print(f"摄像头 {i}: {width}x{height} @ {fps:.1f} FPS")
                    available_cameras.append(i)
                cap.release()
        
        if available_cameras:
            print(f"找到 {len(available_cameras)} 个摄像头: {available_cameras}")
            return available_cameras
        else:
            print("未找到可用的摄像头")
            return []
    
    def open_camera(self, index=None):
        """打开摄像头"""
        if index is not None:
            self.camera_index = index
        
        # 释放之前的摄像头
        if self.camera is not None:
            self.camera.release()
        
        # 尝试打开摄像头
        self.camera = cv2.VideoCapture(self.camera_index, cv2.CAP_DSHOW)
        
        if not self.camera.isOpened():
            print(f"无法打开摄像头 {self.camera_index}")
            return False
        
        # 获取摄像头信息
        width = int(self.camera.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(self.camera.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fps = self.camera.get(cv2.CAP_PROP_FPS)
        
        print(f"摄像头 {self.camera_index} 已打开")
        print(f"分辨率: {width}x{height}")
        print(f"帧率: {fps:.1f} FPS")
        
        return True
    
    def run(self):
        """运行主摄像头循环"""
        # 列出摄像头
        cameras = self.list_cameras()
        if not cameras:
            print("请检查摄像头连接")
            return
        
        # 打开第一个摄像头
        if not self.open_camera(cameras[0]):
            return
        
        self.is_running = True
        
        # 录像相关变量
        is_recording = False
        video_writer = None
        video_filename = None
        
        # 效果变量
        grayscale = False
        blur_effect = False
        
        print("\n摄像头已开启，按 'q' 退出...")
        
        while self.is_running:
            # 读取帧
            ret, frame = self.camera.read()
            
            if not ret:
                print("无法读取摄像头帧")
                break
            
            # 应用效果
            display_frame = frame.copy()
            
            if grayscale:
                display_frame = cv2.cvtColor(display_frame, cv2.COLOR_BGR2GRAY)
                display_frame = cv2.cvtColor(display_frame, cv2.COLOR_GRAY2BGR)
            
            if blur_effect:
                display_frame = cv2.GaussianBlur(display_frame, (15, 15), 0)
            
            # 添加文字信息
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            cv2.putText(display_frame, timestamp, (10, 30), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            
            # 添加状态信息
            status_text = []
            if grayscale:
                status_text.append("灰度模式")
            if blur_effect:
                status_text.append("模糊效果")
            if is_recording:
                status_text.append("录制中")
            
            if status_text:
                cv2.putText(display_frame, " | ".join(status_text), (10, 60), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)
            
            # 显示帧
            cv2.imshow('摄像头 - 按 q 退出', display_frame)
            
            # 处理键盘输入
            key = cv2.waitKey(1) & 0xFF
            
            if key == ord('q'):  # 退出
                break
            elif key == ord(' '):  # 空格键拍照
                self.capture_photo(frame)
            elif key == ord('s'):  # 保存当前帧
                self.save_frame(frame)
            elif key == ord('r'):  # 开始/停止录像
                if not is_recording:
                    # 开始录像
                    video_filename = self.start_recording(frame)
                    if video_filename:
                        is_recording = True
                        print(f"开始录像: {video_filename}")
                else:
                    # 停止录像
                    self.stop_recording(video_writer)
                    is_recording = False
                    video_writer = None
                    print("停止录像")
            elif key == ord('g'):  # 切换灰度模式
                grayscale = not grayscale
                print(f"灰度模式: {'开启' if grayscale else '关闭'}")
            elif key == ord('b'):  # 切换模糊效果
                blur_effect = not blur_effect
                print(f"模糊效果: {'开启' if blur_effect else '关闭'}")
            elif key == ord('c'):  # 切换摄像头
                current_idx = cameras.index(self.camera_index)
                next_idx = (current_idx + 1) % len(cameras)
                if self.open_camera(cameras[next_idx]):
                    print(f"切换到摄像头 {cameras[next_idx]}")
            
            # 如果正在录像，写入帧
            if is_recording and video_writer is not None:
                video_writer.write(frame)
        
        # 清理
        if is_recording and video_writer is not None:
            self.stop_recording(video_writer)
        
        if self.camera is not None:
            self.camera.release()
        
        cv2.destroyAllWindows()
        print("摄像头已关闭")
    
    def capture_photo(self, frame):
        """拍照"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = os.path.join(self.output_dir, f"photo_{timestamp}.jpg")
        
        # 保存照片
        cv2.imwrite(filename, frame)
        print(f"照片已保存: {filename}")
        
        # 显示保存提示
        cv2.putText(frame, "照片已保存!", (50, 100), 
                   cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 3)
        cv2.imshow('摄像头 - 按 q 退出', frame)
        cv2.waitKey(500)  # 显示0.5秒
    
    def save_frame(self, frame):
        """保存当前帧"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = os.path.join(self.output_dir, f"frame_{timestamp}.jpg")
        
        cv2.imwrite(filename, frame)
        print(f"帧已保存: {filename}")
    
    def start_recording(self, frame):
        """开始录像"""
        # 获取帧尺寸
        height, width = frame.shape[:2]
        
        # 生成文件名
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = os.path.join(self.output_dir, f"video_{timestamp}.avi")
        
        # 创建VideoWriter
        fourcc = cv2.VideoWriter_fourcc(*'XVID')
        fps = 20.0
        
        global video_writer
        video_writer = cv2.VideoWriter(filename, fourcc, fps, (width, height))
        
        if video_writer.isOpened():
            return filename
        else:
            print("无法创建视频文件")
            return None
    
    def stop_recording(self, writer):
        """停止录像"""
        if writer is not None:
            writer.release()

def main():
    """主函数"""
    app = CameraApp()
    
    try:
        app.run()
    except KeyboardInterrupt:
        print("\n程序被用户中断")
    except Exception as e:
        print(f"程序出错: {e}")
    finally:
        print("程序结束")

if __name__ == "__main__":
    main()
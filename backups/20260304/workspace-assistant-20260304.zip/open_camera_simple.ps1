# 简单打开相机应用
Write-Host "打开Windows相机应用..."
Start-Process "microsoft.windows.camera:"
Write-Host "已发送打开指令"